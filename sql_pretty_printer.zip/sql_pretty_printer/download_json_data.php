<?php
if(isset($_POST['json']))
{
	header('Content-Type: application/x-download');
	header('Content-Disposition: attachment; filename="'.time().'.txt"');
	header('Cache-Control: private, max-age=0, must-revalidate');
	header('Pragma: public');
	echo stripslashes($_POST['json']);
}
?>

