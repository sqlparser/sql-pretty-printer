<?php
if(isset($_POST['json']))
{
	$_POST['json'] = stripslashes($_POST['json']);
	
	// create curl resource 
	$ch = curl_init(); 
	
	// set url 
	curl_setopt($ch, CURLOPT_URL, "http://69.5.5.152/cgi-bin/index.cgi"); 
	
	//return the transfer as a string 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
	
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        "Content-Type" => "application/x-www-form-urlencoded",
        "Content-Length" => strlen($_POST['json']),
        "accept" => "*/*"
    )); 
	
	curl_setopt($ch, CURLOPT_POST, TRUE); 
	curl_setopt($ch, CURLOPT_POSTFIELDS, $_POST['json']); 
	
	// $output contains the output string 
	$output = curl_exec($ch); 
	
	/*
	if(!curl_errno($ch))
	{
		$info = curl_getinfo($ch);
		print_r($info);
	}*/

	// close curl resource to free up system resources 
	curl_close($ch);
	die($output);
}
?>