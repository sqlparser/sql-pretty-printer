// types of format option input with multiple choice values
var format_options_master = {
								'TFmtListStyle':[
													{label:'Fit Into One Line', value:'fit_into_one_line'},
													{label:'Stacked', value:'stacked'}
												],
								'TFmtCommaOption':[
													{label:'After Item', value:'after_item'},
													{label:'After Item with 1 Space', value:'after_item_with_1_space'},
													{label:'Before Item Inside List', value:'before_item_inside_list'},
													{label:'Before Item Outside List', value:'before_item_outside_list'},
													{label:'Before Item Outside List with n Space', value:'before_item_outside_list_with_n_space'}
												],
								'TFmtANDOR':[
												{label:'At the End of Line', value:'at_the_end_of_line'},
												{label:'At the Begin of Line', value:'at_the_begin_of_line'},
												{label:'At the Begin of Line Outside', value:'at_the_begin_of_line_outside'},
												{label:'At the Begin of Line Left Align with main keyword', value:'at_the_begin_of_line_left_align_with_main_keyword'},
												{label:'At the Begin of Line Right Align with main keyword', value:'at_the_begin_of_line_right_align_with_main_keyword'}
											],
								'TFmtAlign':[
												{label:'Left', value:'left'},
												{label:'Right', value:'right'},
												{label:'None', value:'none'}
											],
								'TFmtVerticalSpacing':[
												{label:'Keep Unchanged', value:'keep_unchanged'},
												{label:'Merge Into One', value:'merge_into_one'},
												{label:'Merge Into One and Insert Blank Link If Not Exists', value:'merge_into_one_and_insert_blank_line_if_not_exists'},
												{label:'Remove All', value:'remove_all'}
											],
								'TFmtCase':[
												{label:'Upper', value:'uppper'},
												{label:'Lower', value:'lower'},
												{label:'No Change', value:'no_change'},
												{label:'Init Cap', value:'init_cap'},
												{label:'Init Cap Start From Second Word', value:'init_cap_start_from_second_word'}
											],
								'TDbVendor':[
												{label:'MSSql', value:'mssql'},
												{label:'Oracle', value:'oracle'},
												{label:'MySql', value:'mysql'},
												{label:'Access', value:'access'},
												{label:'Generic', value:'generic'},
												{label:'DB2', value:'db2'},
												{label:'Sybase', value:'sybase'},
												{label:'Informix', value:'informix'},
												{label:'PostgreSql', value:'postgresql'},
												{label:'Firebird', value:'firebird'},
												{label:'MDX', value:'mdx'},
												{label:'Teradata', value:'teradata'},
												{label:'Netezza', value:'netezza'},
												{label:'ANSI', value:'ansi'},
												{label:'ODBC', value:'odbc'},
												{label:'Hive', value:'hive'},
												{label:'Greenplum', value:'greenplum'}
											]
							};
var actions = {};
var sql_preview,json_output; // sql preview div ACE editor reference
var formatting_json_data;
var dbvendor_json_data;
var temp_children = [];

// creates all html structure including tree of different queries and clauses and format options area
function create_html()
{
	var db_vendor_node = "<li data-clause='"+dbvendor_json_data[0].key+"'>"
							+"<a href='#' onclick=\"return show_format_section(this)\">"+dbvendor_json_data[0].label+"</a>" // query type node
							+"</li>";
	$("#format_tree").append(db_vendor_node);
							
	var section_html = "<div id='format_section_"+dbvendor_json_data[0].key+"' class='format_section' style='display:none'>"
													+"<legend>"+dbvendor_json_data[0].label+"</legend>"
													+"<div class='format_options'></div>"
												+"</div>";
	$("#format_section").append(section_html);
	create_format_option("format_section_"+dbvendor_json_data[0].key,dbvendor_json_data[0]);
	
	
	// looping through each query types to create first node (type of query node in tree)
	$.each(formatting_json_data,
		function(key,query_type)
		{
			// tree strcuture html
			var tree_html = "<li>"
							+"<a href='' role='branch' class='tree-toggle closed' data-toggle='branch'>"+query_type.label+"</a>" // query type node
							+"<ul class='branch closed'>";
			
			// check if clauses are there for query type
			if(typeof(query_type.clauses)!="undefined")
			{
				// looping through each query types clause to create clause of each query type
				$.each(query_type.clauses,
					function(key,clause)
					{
						// create html node in tree for clause
						tree_html += "<li data-query-type='"+query_type.key+"' data-clause='"+clause.key+"' data-sqlid='"+clause.sqlid+"'><a href='#'";
						if(typeof(clause.has_child_options)!="undefined" && clause.has_child_options==true)
						{
							tree_html += " role='branch' class='tree-toggle closed' data-toggle='branch' ";
						}
						else
						{
							tree_html += " onclick=\"return show_format_section(this)\"";
						}
						tree_html += ">"+clause.label+"</a>";
						if(typeof(clause.has_child_options)!="undefined" && clause.has_child_options==true)
						{
							tree_html += "<ul class='branch closed'>";
						}
						else
						{
							//create corresponding html format section for each clause
							var section_html = "<div id='format_section_"+clause.key+clause.sqlid+"' class='format_section' style='display:none'>"
													+"<legend>"+clause.label+"</legend>"
													+"<div class='format_options'></div>"
												+"</div>";
							
							//apppend it to format otpion area
							$("#format_section").append(section_html);
						}
						
						// create html input elements for format options
						if(typeof(clause.format_options)!="undefined")
						{
							$.each(clause.format_options,
							function(key,fmt_op_group)
							{
								if(typeof(fmt_op_group.has_child_options)!="undefined" && fmt_op_group.has_child_options==true)
								{
									tree_html += "<li data-query-type='"+query_type.key+"' data-clause='"+clause.key+"' data-group='"+fmt_op_group.key+"' data-sqlid='"+clause.sqlid+"'>"
									tree_html += "<a href='#' role='branch' class='tree-toggle closed' data-toggle='branch'>"+fmt_op_group.label+"</a>";
									tree_html += "<ul class='branch closed'>";
									$.each(fmt_op_group.format_options,
									function(key,fmt_op_subgroup)
									{
										tree_html += "<li data-query-type='"+query_type.key+"' data-clause='"+clause.key+"' data-group='"+fmt_op_subgroup.key+"' data-parent-group='"+fmt_op_group.key+"' data-sqlid='"+clause.sqlid+"'>"
										tree_html += "<a href='#' onclick=\"return show_format_section(this)\">"+fmt_op_subgroup.label+"</a>";
										
										//create corresponding html format section for each clause
										var section_html = "<div id='format_section_"+clause.key+fmt_op_group.key+fmt_op_subgroup.key+clause.sqlid+"' class='format_section' style='display:none'>"
																+"<legend>"+fmt_op_subgroup.label+"</legend>"
																+"<div class='format_options'></div>"
															+"</div>";
										
										//apppend it to format otpion area
										$("#format_section").append(section_html);
										create_format_option("format_section_"+clause.key+fmt_op_group.key+fmt_op_subgroup.key+clause.sqlid,fmt_op_subgroup);
									});
									tree_html += "</ul>";
								}
								else
								{
									if(typeof(clause.has_child_options)!="undefined" && clause.has_child_options==true)
									{
										tree_html += "<li data-query-type='"+query_type.key+"' data-clause='"+clause.key+"' data-group='"+fmt_op_group.key+"' data-sqlid='"+clause.sqlid+"'>"
										tree_html += "<a href='#' onclick=\"return show_format_section(this)\">"+fmt_op_group.label+"</a>";
										
										//create corresponding html format section for each clause
										var section_html = "<div id='format_section_"+clause.key+fmt_op_group.key+clause.sqlid+"' class='format_section' style='display:none'>"
																+"<legend>"+fmt_op_group.label+"</legend>"
																+"<div class='format_options'></div>"
															+"</div>";
										
										//apppend it to format otpion area
										$("#format_section").append(section_html);
										// to create format options in each clause format section
										create_format_option("format_section_"+clause.key+fmt_op_group.key+clause.sqlid,fmt_op_group);
									}
									else
									{
										// to create format options in each clause format section
										create_format_option("format_section_"+clause.key+clause.sqlid,fmt_op_group);
									}
								}
							});
						}
						
						if(typeof(clause.has_child_options)!="undefined" && clause.has_child_options==true)
						{
							tree_html += "</ul>";
						}
						tree_html += "</li>";
					}
				);
			}
			
			tree_html += "</ul></li>";
			
			//append tree html in tree area
			$("#format_tree").append(tree_html);
		}
	);
	
	// by default select first clause to trigger first clause format option
	$("#format_tree li:first>a").trigger("click");
	//$("#format_tree ul:first li:first>a").trigger("click");
	//$("#format_tree ul:first li:first ul:first li:first>a").trigger("click");
}

// to create format option html
function create_format_option(section_id,fmt_op_group)
{
	var format_option_group = fmt_op_group.key;
	format_options = fmt_op_group.option_elements;
	//loop through all format options
	$.each(format_options,
		function(key,option)
		{
			var action_array = []; // all actions in one array
			var visibility = option.initial_visibility=="hidden" ? "none":"block";
			
			
			// check for action options
			if(typeof(option.actions)!="undefined")
			{
				actions[option.id] = option.actions;
				//loop through all action elements
				$.each(option.actions,
					function(key,action_option)
					{
						//add action to action array
						action_array.push({on:action_option.on,show:action_option.show});
					}
				);
			}
			
			// format option html
			var fmt_op_html = "<div id='format_option_"+option.id+"' style='display:"+visibility+"' class='form-group'>"
								+"<label class='control-label col-xs-4'>"+option.label+"</label>";
			fmt_op_html += "<div class='col-xs-8'>"+get_input_option(option,format_option_group)+"</div>";
			fmt_op_html += "</div>";
			
			// append format option html to formating area
			$("#"+section_id).append(fmt_op_html);
		}
	);
}

//to create input option html
function get_input_option(data,group)
{
	var html = "";
	var type = data.type.toLowerCase();
	var id = data.id;
	switch(type)
	{
		// to create checkbox option
		case 'tfmtboolean':
			var checked = data.default_value==true?"checked='checked'":"";
			html += "<input type='checkbox' id='"+id+"' name='"+id+"' data-format-type='tfmtboolean' data-format-group='"+group+"' onclick=\"toggle_format_option(this);get_formatted_sql('"+id+"');\" "+checked+" />";
			break;
		// to create textbox option
		case 'int':
			html += "<input type='text' maxlength='3' class='form-control col-xs-7' id='"+id+"' data-old-value='"+data.default_value+"' data-format-group='"+group+"' data-format-type='int' onkeyup='get_formatted_sql_text(this)'name='"+id+"' value='"+data.default_value+"' />";
			break;
		// to create list style selection dropdown
		case 'tfmtliststyle':
			var fmt_op = format_options_master.TFmtListStyle;
			html += "<select id='"+id+"' name='"+id+"' class='form-control col-xs-7' data-format-type='tfmtliststyle' data-format-group='"+group+"' onchange=\"toggle_format_option(this);get_formatted_sql('"+id+"');\">";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
		// to create comma option dropdown
		case 'tfmtcommaoption':
			var fmt_op = format_options_master.TFmtCommaOption;
			html += "<select id='"+id+"' name='"+id+"' class='form-control' data-format-type='tfmtcommaoption' data-format-group='"+group+"' onchange=\"toggle_format_option(this);get_formatted_sql('"+id+"');\">";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
		case 'tfmtandor':
			var fmt_op = format_options_master.TFmtANDOR;
			html += "<select id='"+id+"' name='"+id+"' class='form-control' data-format-type='tfmtandor' data-format-group='"+group+"' onchange=\"toggle_format_option(this);get_formatted_sql('"+id+"');\">";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
		case 'tfmtalign':
			var fmt_op = format_options_master.TFmtAlign;
			html += "<select id='"+id+"' name='"+id+"' class='form-control' data-format-type='tfmtandor' data-format-group='"+group+"' onchange=\"toggle_format_option(this);get_formatted_sql('"+id+"');\">";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
		case 'tfmtverticalspacing':
			var fmt_op = format_options_master.TFmtVerticalSpacing;
			html += "<select id='"+id+"' name='"+id+"' class='form-control' data-format-type='tfmtandor' data-format-group='"+group+"' onchange=\"toggle_format_option(this);get_formatted_sql('"+id+"');\">";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
		case 'tfmtcase':
			var fmt_op = format_options_master.TFmtCase;
			html += "<select id='"+id+"' name='"+id+"' class='form-control' data-format-type='tfmtandor' data-format-group='"+group+"' onchange=\"toggle_format_option(this);get_formatted_sql('"+id+"');\">";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
		case 'tdbvendor':
			var fmt_op = format_options_master.TDbVendor;
			html += "<select id='"+id+"' name='"+id+"' class='form-control' data-format-type='tfmtandor' data-format-group='"+group+"'>";
			
			for(i=0;i<fmt_op.length;i++)
			{
				html += "<option value='"+fmt_op[i].value+"'";
				if(data.default_value==fmt_op[i].value)
					html += " selected";
				html += ">"+fmt_op[i].label+"</option>";
			}
			html += "</select>";
			break;
	}
	return html;
}

function get_formatted_sql_text(cmp)
{
	if($(cmp).val()!="" && $(cmp).attr('data-old-value')!=$(cmp).val())
	{ 
		id = $(cmp).attr("id");
		$(cmp).attr('data-old-value',$(cmp).val());
		get_formatted_sql(id);
	}
}

//to show format option on user action
function toggle_format_option(cmp)
{
	var type = $(cmp).attr("data-format-type");
	var id = $(cmp).attr("id");
	var cmp_actions = actions[id];
	var cmp_value;
	switch(type)
	{
		// to show format option on check/uncheck of checkbox
		case "tfmtboolean":
			cmp_value = $(cmp).prop("checked");
		break;
		// to show format option change value of dropdown
		case "tfmtliststyle":
		case "tfmtcommaoption":
		case "tfmtalign":
		case "tfmtverticalspacing":
		case "tfmtcase":
			cmp_value = $(cmp).val();
		case "tdbvendor":
			cmp_value = $(cmp).val();
		break;
	}
	
	$.each(cmp_actions,
		function(key,action)
		{
			if(cmp_value==action.on)
			{
				child_cmp = $("#format_option_"+action.show).show().children().find(".form-control").focus();
				toggle_format_option(child_cmp);
			}
			else
			{
				temp_children = [];
				var children = get_all_child_options(action.show);
				$.each(children,
				function(key,value)
				{
					$("#format_option_"+value).hide();	
				});
			}
		}
	);
}

function get_all_child_options(id)
{
	temp_children.push(id);
	if(typeof(actions[id])!="undefined")
	{
		$.each(actions[id],
			function(key,action)
			{
				get_all_child_options(action.show);
			}
		);
	}
	return temp_children;
}

// to switch through different format section of clauses
function show_format_section(c)
{
	$("li.active").removeClass("active");
	section_id = typeof($(c).parent().attr("data-sqlid"))=="undefined"?"":$(c).parent().attr("data-sqlid");
	clause = typeof($(c).parent().attr("data-clause"))=="undefined"?"":$(c).parent().attr("data-clause");
	parent_group = typeof($(c).parent().attr("data-parent-group"))=="undefined"?"":$(c).parent().attr("data-parent-group");
	group = typeof($(c).parent().attr("data-group"))=="undefined"?"":$(c).parent().attr("data-group");
	$(c).parent().addClass("active");
	$(".format_section").hide();
	$("#format_section_"+clause+parent_group+group+section_id).show();
	sql_preview.setValue("",1);
	json_output.setValue("",1);
	var first_option = $("#format_section_"+clause+parent_group+group+section_id).find("input:first");
	if(first_option.length==0)
	{
		first_option = $("#format_section_"+clause+parent_group+group+section_id).find("select:first");
	}
	if(clause!="dbvendor")
	{
		get_formatted_sql($(first_option).attr("id"));// by default get formatted sql
	}
	return false;
}

// to communicate with back end program and show formatted sql string
function get_formatted_sql(op_id)
{
	var json_output_data = create_json_output(op_id);
	$.ajax
	(
		{
			type:"post",
			url:"get_fmt_sql.php",
			data:"json="+json_output_data,
			dataType:"json",
			error:function(request,textStatus,errorThrown)
			{
				sql_preview.setValue(request.responseText,1);
			},
			success:function(r)
			{
				sql_preview.setValue(r.formattedSql,1);
			}
		}
	);
}

function create_json_output(op_id)
{
	var json_output_data = {dbVendor:$("#fmt_dbvendor").val(),formatOptions:{}};
	var active_li = $("#format_tree li.active");
	var current_query_type = $(active_li).attr("data-query-type");
	var current_clause_sqlid = $(active_li).attr("data-sqlid");
	var current_clause = $(active_li).attr("data-clause");
	var option_json_temp = {};
	for(i=0;i<formatting_json_data.length;i++)
	{
		if(formatting_json_data[i].key==current_query_type)
		{
			json_output_data.formatOptions[formatting_json_data[i].key] = {};
			var clauses = formatting_json_data[i].clauses;
			for(j=0;j<clauses.length;j++)
			{
				if(clauses[j].sqlid==current_clause_sqlid && current_clause==clauses[j].key)
				{
					json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key] = {};
					var fmt_op_groups = clauses[j].format_options;
					for(k=0;k<fmt_op_groups.length;k++)
					{
						fmt_group = fmt_op_groups[k];
						
						if(typeof fmt_group.has_child_options !="undefined" && fmt_group.key==$(active_li).attr("data-parent-group"))
						{
							var fmt_op_sub_groups = fmt_group.format_options;
							for(x=0;x<fmt_op_sub_groups.length;x++)
							{
								fmt_sub_group = fmt_op_sub_groups[x];
								if(fmt_sub_group.key==$("#"+op_id).attr("data-format-group"))
								{
									var temp_sql_id = typeof(fmt_sub_group.sqlid)=="undefined"?clauses[j].sqlid:fmt_sub_group.sqlid;
									if(fmt_group.key!="")
									{
										json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key] = {};
										json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key][fmt_sub_group.key] = {sqlid:temp_sql_id};
									}
									else
									{
										json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_sub_group.key] = {sqlid:temp_sql_id};
									}
									var fmt_op_elements = fmt_sub_group.option_elements;
									for(a=0;a<fmt_op_elements.length;a++)
									{
										op_element = fmt_op_elements[a];
										if($("#format_option_"+op_element.id).css("display")=="none")
										{
											continue;
										}
										var op_ele_val;
										if(op_element.type.toLowerCase()=="tfmtboolean")
											op_ele_val = $("#"+op_element.id).prop("checked");
										else
											op_ele_val = $("#"+op_element.id).val();
										
										if(fmt_group.key!="")
										{
											json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key][fmt_sub_group.key][op_element.id] = op_ele_val;
										}
										else
										{
											json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_sub_group.key][op_element.id] = op_ele_val;
										}
									}
									
									break;
								}
							}
							break;
						}
						
						if(fmt_group.key==$("#"+op_id).attr("data-format-group") && typeof($(active_li).attr("data-parent-group"))=="undefined")
						{
							var temp_sql_id = typeof(fmt_group.sqlid)=="undefined"?clauses[j].sqlid:fmt_group.sqlid;
							if(fmt_group.key!="")
							{
								json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key] = {sqlid:temp_sql_id};
							}
							else
							{
								json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key] = {sqlid:temp_sql_id};
							}
							var fmt_op_elements = fmt_group.option_elements;
							for(a=0;a<fmt_op_elements.length;a++)
							{
								op_element = fmt_op_elements[a];
								if($("#format_option_"+op_element.id).css("display")=="none")
								{
									continue;
								}
								var op_ele_val;
								if(op_element.type.toLowerCase()=="tfmtboolean")
									op_ele_val = $("#"+op_element.id).prop("checked");
								else
									op_ele_val = $("#"+op_element.id).val();
								
								if(fmt_group.key!="")
								{
									json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key][op_element.id] = op_ele_val;
								}
								else
								{
									json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][op_element.id] = op_ele_val;
								}
							}
							
							break;
						}
					}
					break;
				}
			}
			break;
		}
	}
	
	json_output_data = JSON.stringify(json_output_data);
	json_output.setValue(json_output_data,1);
	return json_output_data;
}

function create_whole_json_output()
{
	var json_output_data = {dbVendor:$("#fmt_dbvendor").val(),formatOptions:{}};
	var active_li = $("#format_tree li.active");
	var current_query_type = $(active_li).attr("data-query-type");
	var current_clause_sqlid = $(active_li).attr("data-sqlid");
	var current_clause = $(active_li).attr("data-clause");
	for(i=0;i<formatting_json_data.length;i++)
	{
		//if(formatting_json_data[i].key==current_query_type)
		{
			json_output_data.formatOptions[formatting_json_data[i].key] = {};
			var clauses = formatting_json_data[i].clauses;
			for(j=0;j<clauses.length;j++)
			{
				//if(clauses[i].sqlid==current_clause_sqlid)
				{
					json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key] = {};
					var fmt_op_groups = clauses[j].format_options;
					$.each(fmt_op_groups,
						function(key,fmt_group)
						{
							if(typeof fmt_group.has_child_options !="undefined")
							{
								if(fmt_group.key!="")
								{
									json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key] = {};
								}
								var fmt_op_sub_groups = fmt_group.format_options;
								for(x=0;x<fmt_op_sub_groups.length;x++)
								{
									fmt_sub_group = fmt_op_sub_groups[x];
									//if(fmt_sub_group.key==$("#"+op_id).attr("data-format-group"))
									{
										var temp_sql_id = typeof(fmt_sub_group.sqlid)=="undefined"?clauses[j].sqlid:fmt_sub_group.sqlid;
										if(fmt_group.key!="")
										{
											json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key][fmt_sub_group.key] = {sqlid:temp_sql_id};
										}
										else
										{
											json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_sub_group.key] = {sqlid:temp_sql_id};
										}
										var fmt_op_elements = fmt_sub_group.option_elements;
										for(a=0;a<fmt_op_elements.length;a++)
										{
											op_element = fmt_op_elements[a];
											var op_ele_val;
											if(op_element.type.toLowerCase()=="tfmtboolean")
												op_ele_val = $("#"+op_element.id).prop("checked");
											else
												op_ele_val = $("#"+op_element.id).val();
											
											if(fmt_group.key!="")
											{
												json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key][fmt_sub_group.key][op_element.id] = op_ele_val;
											}
											else
											{
												json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_sub_group.key][op_element.id] = op_ele_val;
											}
										}
									}
								}
							}
							else
							{
								var temp_sql_id = typeof(fmt_group.sqlid)=="undefined"?clauses[j].sqlid:fmt_group.sqlid;
								if(fmt_group.key!="")
								{
									json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key] = {sqlid:temp_sql_id};
								}
								else
								{
									json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key] = {sqlid:temp_sql_id};
								}
								var fmt_op_elements = fmt_group.option_elements;
								$.each(fmt_op_elements,
									function(key,op_element)
									{
										var op_ele_val;
										if(op_element.type.toLowerCase()=="tfmtboolean")
											op_ele_val = $("#"+op_element.id).prop("checked");
										else
											op_ele_val = $("#"+op_element.id).val();
										
										if(fmt_group.key!="")
										{
											json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][fmt_group.key][op_element.id] = op_ele_val;
										}
										else
										{
											json_output_data.formatOptions[formatting_json_data[i].key][clauses[j].key][op_element.id] = op_ele_val;
										}
									}
								);
							}
						}
					);
					//break;
				}
			}
			//break;
		}
	}
	json_output_data = JSON.stringify(json_output_data);
	json_output.setValue(json_output_data,1);
	return json_output_data;
}

function download_json_data()
{
	var json_data = create_whole_json_output();
	$("#form_download #json").val(json_data);
	$("#form_download").submit();
}
$(function()
{
	// load formatting optionn json data at very start
	$.ajax
	(
		{
			type:"GET",
			url:"assets/data/formatting_data.min.json",
			dataType:"json",
			error:function(jqXHR,textStatus,errorThrown)
			{
				alert(textStatus);	
			},
			success:function(r)
			{
				formatting_json_data = r.slice(1);
				dbvendor_json_data = r.slice(0,1);
				create_html();
			}
		}
	);
	
	// bind click event with previous button
	$(".btn_previous").click(function()
	{
		$("li.active").prev().find("a").trigger("click");
	});
	
	//bid click event with next button
	$(".btn_next").click(function()
	{
		$("li.active").next().find("a").trigger("click");
	});
	
	$(".btn_save").click(function()
	{
		download_json_data();
	});
	
	// create sql preview editor
	sql_preview = ace.edit("sql_preview");
    sql_preview.setTheme("ace/theme/theme-solarized_light");
    sql_preview.getSession().setMode("ace/mode/sql");
	sql_preview.setReadOnly(true);
	sql_preview.setHighlightActiveLine(false);
	
	json_output = ace.edit("json_output");
    json_output.setTheme("ace/theme/theme-solarized_light");
    json_output.getSession().setMode("ace/mode/json");
	json_output.setReadOnly(true);
	json_output.setHighlightActiveLine(false);
});