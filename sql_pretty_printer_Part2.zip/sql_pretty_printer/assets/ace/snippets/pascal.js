ace.define('ace/snippets/pascal', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "pascal";

});
