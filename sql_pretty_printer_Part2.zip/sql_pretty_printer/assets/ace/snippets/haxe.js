ace.define('ace/snippets/haxe', ['require', 'exports', 'module' ], function(require, exports, module) {


exports.snippetText = "";
exports.scope = "haxe";

});
